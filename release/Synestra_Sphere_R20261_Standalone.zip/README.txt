SYNESTRA - SPHERE ENERGETIQUE 3D - R202.61
================================================

Version autonome du Labo Babylon. Aucun compte ni serveur distant.

DEMARRAGE :
1. Double-cliquer sur index.html dans Chrome ou Edge.
2. Si les scripts locaux sont bloques, lancer START_SPHERE.cmd.
   Python 3 est necessaire pour ce mode de secours.
   Le serveur demarre UNIQUEMENT sur 127.0.0.1:5182.
   L'adresse s'ouvre dans le navigateur APRES la mise en ecoute.
   Ctrl+C dans la console arrete le serveur.
   Si le port 5182 est occupe, le lancement echoue sans ouvrir de navigateur.

CONTENU :
index.html, style.css, dist/babylon-lab.js,
START_SPHERE.cmd, launch_sphere.py, README.txt.
Fichiers web locaux uniquement, aucune requete Internet.

FONCTIONS :
- Rayonnement, vortex, tressage et pulsation, transitions fluides.
- 28 flux externes, 18 filaments internes, 6 noeuds mobiles et noyau 80 triangles.
- Controle souris, molette, geste tactile et option reduire les animations.
- Puissance 0 % : extinction du noyau et des connexions.

PREUVE :
ZIP autonome teste sur Windows / Chrome WebGL2 / RTX 3090.
La validation artistique proprietaire reste independante de ce test technique.
