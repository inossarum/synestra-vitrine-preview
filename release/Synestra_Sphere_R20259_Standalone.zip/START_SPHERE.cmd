@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>&1
if %errorlevel%==0 (
  start "" "http://127.0.0.1:5182/"
  python -m http.server 5182 --bind 127.0.0.1
  exit /b %errorlevel%
)
where py >nul 2>&1
if %errorlevel%==0 (
  start "" "http://127.0.0.1:5182/"
  py -3 -m http.server 5182 --bind 127.0.0.1
  exit /b %errorlevel%
)
echo Python 3 introuvable. Ouvrez index.html avec votre navigateur.
pause
