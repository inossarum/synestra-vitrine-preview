SYNESTRA — SPHÈRE ÉNERGÉTIQUE 3D — R202.59
================================================

Version autonome du Labo 3D Babylon. Pas de serveur distant, de compte ou de service payant.

OUVERTURE :
1) Double-cliquer sur index.html dans Chrome ou Edge.
2) Si votre navigateur bloque les scripts locaux, utiliser START_SPHERE.cmd
   (Python 3 requis, déjà disponible sur Inos-Cerebros). Le serveur est limité à
   127.0.0.1:5182. Arrêter le processus avec Ctrl+C.

FONCTIONS :
- Quatre formes de courants (rayonnement, vortex, tressage, pulsation).
- Transition fluide 0,72 s entre les formes, même lors de changements rapides.
- 28 flux externes, 18 filaments centraux, 6 noeuds mobiles, noyau 80 triangles.
- Souris : mouvement/orbite ; molette : zoom. Respect de l'option réduire les animations.
- Puissance 0 % : extinction du noyau et des connexions.
- Trois qualités manuelles et un mode automatique.

CONTENU :
index.html, style.css, dist/babylon-lab.js, START_SPHERE.cmd.
Toutes les ressources utilisées par la sphère sont locales ; aucune URL externe n'est chargée.

VERSION SOURCE :
Dépôt inossarum/synestra-vitrine-preview ; branche task/SYN_LAB_R20259_FINAL_CANDIDATE_20261103.
Aucune installation, modification système ou exécution en administrateur requise.

Cette archive est une prévisualisation indépendante, pas un déploiement de la vitrine publique.
